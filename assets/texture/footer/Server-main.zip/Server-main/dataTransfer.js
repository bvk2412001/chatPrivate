//dữ liệu chuyển giữa clients và server
//idSocket: là id của clients đang giao tiếp với server
//data : là thông tin giao tiếp của cliets và server
//dateTime: là thời điểm giao tiếp 

const dataTransfer = {
    socket_id: "",
    inf_user: {},
    data: {},
    dateTime: {}
}


export default dataTransfer